# Deployment package `fixed-point-v1` for run run-20261009-020719-96623f

Model gru (hidden 6) executed as gru_stream; weights 11eee40f80af.
Software: opendpd 2.3.1, torch 2.13.0+cu132.

## Verification

Backend `c99`: **bit_exact** (6 golden vectors replayed through the compiled C99 reference; every output sample and every state step equal to the software reference); compiler `/usr/bin/cc`.

## Golden vectors

| case | samples | resets | description | output sha256 |
|---|---:|---|---|---|
| normal | 718 | - | the first 4096 samples of the test split | 61faba1f3a6f |
| extreme | 512 | - | full-scale inputs: constant +max, constant -max, alternating | 41ffd71d5807 |
| saturation | 1024 | - | random full-scale signs: pre-activations beyond the table ranges, state at its bounds | d24320f08d5c |
| all_zero | 256 | - | zero input: the state stays at zero and the output is the bias path | 47ba544d8c7b |
| state_reset | 1024 | [0, 256, 512, 768] | one 256-sample block four times with a reset before each; the four outputs are identical | 87bb24532f7a |
| long_sequence | 2048 | - | 2048 samples of the test split (tiled when shorter): no drift, no overflow | eb59f7d2a781 |

## Float to fixed: quality loss (profile opendpd-spectral-v2, test split)

| metric | float | fixed | fixed - float |
|---|---:|---:|---:|
| NMSE (dB) | -4.101 | -4.095 | 0.006 |
| IBE (dB) | -4.049 | -4.045 | 0.004 |
| ACLR_L (dBc) | -30.639 | -30.329 | 0.310 |
| ACLR_R (dBc) | -20.241 | -20.237 | 0.004 |
| ACLR_AVG (dBc) | -25.440 | -25.283 | 0.157 |

## Resources

Label **theoretical** (from the specification and the shapes; nothing measured):

- MAC per sample: 156; table lookups per sample: 18
- weights 312 bytes, biases 152 bytes, state 12 bytes, tables 3072 bytes
- sparsity: none exploited: every MAC is executed

Label **measured_execution_time**: 1,515,989 samples/s, the compiled C99 reference replaying the long_sequence golden vector, single thread (x86_64). A property of this build on this machine, not of a deployment.

Label **synthesis_estimate**: not available (nothing was synthesised).
Label **measured_power**: not available (nothing was measured); energy is never inferred from MAC or parameter counts.

## Execution assumptions

- one sample per step, sequential; the state (spec.h) is carried across samples and chunks (gru_stream semantics)
- two's-complement integers; right shifts are floors implemented with division (no arithmetic-shift assumption)
- dot products are exact in the accumulator (int64 in the references); the bound is checked, never wrapped
- no parallelism, pipelining or sparsity is assumed; the C reference is single-threaded
- the input is already in spec.x: analogue front-end, AGC and I/Q calibration are outside this package

## Weight formats

| tensor | shape | bits | fraction | max abs (float) | saturated |
|---|---|---:|---:|---:|---:|
| w_ih | [18, 2] | 12 | 11 | 0.8132 | 0 |
| w_hh | [18, 6] | 12 | 11 | 0.9816 | 0 |
| w_out | [2, 6] | 12 | 11 | 0.8268 | 0 |
| b_ih | [18] | 28 | 18 | 0.02465 | 0 |
| b_hh | [18] | 28 | 18 | 0.02465 | 0 |
| b_out | [2] | 28 | 18 | 0.006317 | 0 |

Files and hashes are listed in `manifest.json`; `c/` holds the generated reference and the harness (`cc -std=c99 -O2 -o harness gru_fixed.c harness.c`; `./harness golden/<case>/x.i16 <n> y.out h.out [reset ...]`).
