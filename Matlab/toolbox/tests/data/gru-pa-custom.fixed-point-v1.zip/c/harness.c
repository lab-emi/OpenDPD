/* Replays a golden vector: harness x.i16 n y.out h.out [reset_index ...]
 * x.i16: n * GRU_INPUTS little-endian int16; writes y (n * GRU_OUTPUTS) and the per-step state (n * GRU_HIDDEN). */
#include <stdio.h>
#include <stdlib.h>
#include "gru_fixed.h"
int main(int argc, char **argv) {
    if (argc < 5) { fprintf(stderr, "usage: harness x.i16 n y.out h.out [reset ...]\n"); return 2; }
    long n = atol(argv[2]);
    FILE *fx = fopen(argv[1], "rb"), *fy = fopen(argv[3], "wb"), *fh = fopen(argv[4], "wb");
    if (!fx || !fy || !fh) { fprintf(stderr, "cannot open files\n"); return 2; }
    int n_resets = argc - 5;
    long *resets = n_resets ? (long *)malloc(sizeof(long) * n_resets) : NULL;
    for (int i = 0; i < n_resets; i++) resets[i] = atol(argv[5 + i]);
    gru_state_t st;
    gru_fixed_reset(&st);
    int16_t x[GRU_INPUTS], y[GRU_OUTPUTS];
    for (long i = 0; i < n; i++) {
        for (int k = 0; k < n_resets; k++) if (resets[k] == i) gru_fixed_reset(&st);
        if (fread(x, sizeof(int16_t), GRU_INPUTS, fx) != (size_t)GRU_INPUTS) { fprintf(stderr, "short input\n"); return 3; }
        gru_fixed_step(&st, x, y);
        fwrite(y, sizeof(int16_t), GRU_OUTPUTS, fy);
        fwrite(st.h, sizeof(int16_t), GRU_HIDDEN, fh);
    }
    fclose(fx); fclose(fy); fclose(fh);
    free(resets);
    return 0;
}
