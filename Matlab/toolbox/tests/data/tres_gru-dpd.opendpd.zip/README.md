# OpenDPD model package (tres_gru, dpd)

Format: `opendpd-model-v1`. This package holds data only: `manifest.json`, `weights.mat` and `weights.npz` (the same arrays),
`golden/` (a test input and the outputs OpenDPD produced for it) and this file. Nothing in it is executed.

* In MATLAB, with the OpenDPD toolbox: `model = opendpd.load("<this file>")`, then `opendpd.verify(model)` checks the
  golden outputs (absolute error 1e-05), `y = opendpd.apply(model, x)` applies the model. No Python is needed.
* Anywhere else: read `weights.npz` and `manifest.json`; `manifest.json` states the architecture and the execution
  semantics, and `golden/golden.npz` is the test vector.

What it is: the dpd model `tres_gru` from run `run-20261008-224014-3ab167`. Evidence: simulation (dataset origin: synthetic). Samples are not normalised or
aligned: supply them in the units and at the sample rate of the training dataset (8e+07 Hz,
amplitude units: unknown). Input amplitude seen in training: rms 0.245071, peak 0.596845; outputs
for inputs far outside that range are extrapolation.

Execution semantics are in `manifest.json` under `execution`: `offline_segmented` is how the run was scored
(state reset every 128 samples); `streaming_stateful` is not available for this model.
Licence: Apache-2.0, as OpenDPD.
